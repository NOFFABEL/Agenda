package com.sdk.model;
/**
 * <p>The enum <code>SMSType</code> provides
 * to maintain the type of SMS codes.</p>
 *
 */
public enum SMSType {
	TOP("N",true),
	DIRECT("L",false);

	private String code;
	private boolean has_custom_tpoa;

	private SMSType(final String code, final boolean has_custom_tpoa) {
		this.code = code;
		this.has_custom_tpoa = has_custom_tpoa;
	}

	public String code() {
		return code;
	}

	public boolean hasCustomTPOA() {
		return has_custom_tpoa;
	}

	@Override
	public String toString() {
		return "'" + name() + "' (with value '" + code + "')";
	}

	public static SMSType fromCode(final String code) {
		for (final SMSType credit_type : SMSType.values()) {
			if (credit_type.code.equalsIgnoreCase(code))
				return credit_type;
		}
		throw new IllegalArgumentException("Invalid credit type: "+code);
	}

}
