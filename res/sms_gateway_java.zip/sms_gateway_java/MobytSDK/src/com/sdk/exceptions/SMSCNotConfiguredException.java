package com.sdk.exceptions;

public class SMSCNotConfiguredException extends SMSCException {
	private static final long serialVersionUID = -1897383557844511629L;

	public SMSCNotConfiguredException(final String message) {
		super(message);
	}

}
