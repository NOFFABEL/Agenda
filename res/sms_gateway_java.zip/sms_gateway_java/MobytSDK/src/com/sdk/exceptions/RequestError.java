package com.sdk.exceptions;

public class RequestError {
	public static final int RESPONSE_ERROR = -1;
	public static final int CONNECTION_ERROR = -2;
}
