package com.sdk.exceptions;


public class InvalidMessageContentException extends SMSCException {
	private static final long serialVersionUID = 7584467205582460680L;

	public InvalidMessageContentException(final String arg0) {
		super(arg0);
	}
}
