package com.sdk.exceptions;


public class InvalidRecipientException extends SMSCException {
	private static final long serialVersionUID = 935519652334600273L;

}
