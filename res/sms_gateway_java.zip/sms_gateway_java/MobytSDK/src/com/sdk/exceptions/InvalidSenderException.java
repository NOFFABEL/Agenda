package com.sdk.exceptions;


public class InvalidSenderException extends SMSCException {
	private static final long serialVersionUID = 7189148175786168041L;

}
