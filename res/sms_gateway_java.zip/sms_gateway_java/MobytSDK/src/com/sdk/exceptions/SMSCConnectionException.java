package com.sdk.exceptions;

public class SMSCConnectionException extends SMSCException {
	private static final long serialVersionUID = 7868058981922299457L;

}
