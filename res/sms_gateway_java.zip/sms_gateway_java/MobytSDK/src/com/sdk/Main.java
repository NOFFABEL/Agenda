package com.sdk;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.sdk.connection.SMSCConnection;
import com.sdk.connection.SMSCConnectionFactory;
import com.sdk.exceptions.SMSCException;
import com.sdk.exceptions.SMSCRemoteException;
import com.sdk.model.SMS;
import com.sdk.model.SMSType;
import com.sdk.model.SendResult;
import com.sdk.model.Subaccount;

public class Main implements Runnable {
	private static final int ST = 10;

	static Random r = new Random();
	public static void main(final String[] args) throws InterruptedException {
		List<Thread> tt = new ArrayList<Thread>();
		Thread t = null;
		for (int i=0;i<20;i++) {
			t = new Thread(new Main());
			tt.add(t);
			t.start();
			Thread.sleep(500);
			System.out.println("thread " + i + " started");
		}
		t.join();
	}

	public void run() {
		while (true) {
		try {
			SMSCConnection connection = SMSCConnectionFactory.openConnection("xxx", "xxx");
			for (int j = 0; j < 5; j++) {
				SMS sms = new SMS();
				for (int i = 0; i < 10; i++) {
					sms.addSmsRecipient("+3934" + String.valueOf(1000 + j) + String.valueOf(1000 + i));
					sms.addSmsRecipient("+39347905" + (1000 + j));
				}
				sms.setSms_type(SMSType.TOP);
				sms.setMessage("àèòéóíú");
				sms.setSms_sender("pippo");
				sms.setImmediate();
				// sms.setOrder_id("FFFAAABBBC");
				SendResult result = connection.sendSMS(sms);
				System.out.println("SendResult: " + result.toString());
				try {
					Thread.sleep(2500);
				} catch (Exception e) {
				}
			}
			List<Subaccount> subs = connection.getSubaccounts();
			connection.getCredits();
			connection.getMessageStatus("asdf");
			connection.getSMS_MOById(1);
			for (Subaccount s : subs) {
				s.setSubaccountType(Subaccount.SUBACCOUNT_TYPE.COMPANY);
//				System.out.println("------------------------");
//				Obj.printObject(s, System.out);
//				List<Credit> credits = 
				connection.getSubaccountCredits(s);
//				for (Credit c : credits)
//					Obj.printObject(c, System.out);
			}
			try {
				Thread.sleep(ST + r.nextInt(ST));
			} catch (InterruptedException e) { }
		} catch (final SMSCRemoteException smscre) {
//			System.out.println("Exception! Message: " + smscre.getMessage());
//			smscre.printStackTrace();
		} catch (final SMSCException smsce) {
//			smsce.printStackTrace();
		}
		}
	}

}
