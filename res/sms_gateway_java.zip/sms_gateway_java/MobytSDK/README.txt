 - README -

quickstart:
	- open Mobyt.jar as a zip file (e.g. using WinZip, maybe you have to rename it to Mobyt.zip)
	- edit sdk.properties inside the zip archive and change username+password with your Mobyt data
	- include Mobyt.jar in your java classpath
