<?php

define('SDK_HOSTNAME','api.mobyt.fr');
define('SDK_USERNAME','your@login');
define('SDK_PASSWORD','password');
define('SDK_DEFAULT_PORT',80);
define('SDK_PROXY','');
define('SDK_PROXY_PORT',8080);

?>
